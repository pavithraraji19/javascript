var staff=[
    {name:"aaa",age:10,country:"india"},
    {name:"bbb",age:20,country:"afghanistan"},
    {name:"cc",age:30,country:"italy"},
    {name:"ddd",age:40,country:"spain"},
    {name:"eee",age:50,country:"india"},
    {name:"fff",age:60,country:"india"}
]
var resultArr=[];
for(var i=0;i<staff.length;i++)
    if(staff[i].age<30)
    {
        resultArr.push(staff[i])
    }

console.log(resultArr)
var countryArr=[];
for(var i=0;i<staff.length;i++)
    if(staff[i].country=="india")
    {
        countryArr.push(staff[i])
    }
    console.log(countryArr)