document.getElementById('txt').value="Text here";
document.getElementsByTagName('input')[1].value="Input Value";

function getAndSetVal()
{
    var txt1=document.getElementById('txt').value;
    document.getElementById('txt2').value=txt1;
}


function getVal()
{
var txt=document.getElementById("txt").value;
alert(txt);
}





