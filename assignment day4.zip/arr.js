var detail=[
    {name:"aaa",age:10,country:"india",hobby:"drawing"}

]
console.log(detail)
//to display all the objects
str=JSON.stringify(detail)
console.log(str);