let employees=[
    {
        name:"Chris Prat",
        age :40,
        city:"Sydney",
        salary:"50000"
     },
     {
        name:"Diaz Cameron",
        age :39,
        city:"Texas",
        salary:40000
     },
     {
        name:"Scarlett",
        age :35,
        city:"Sau Paulo",
        salary:60000 
     },
]
function display(employeearray){
    let tabledata=""
    employeearray.forEach(function(employees,index){
        let currentrow=`<tr>
                       <td>${employees.name}</td>
                       <td>${employees.age}</td>
                       <td>${employees.city}</td>
                       <td>${employees.salary}</td>
                       <td><button onclick="deleteemployee(${index})">delete</button></td>
                       </tr>`;
        tabledata+=currentrow;          
        });
document.getElementById("tdata").innerHTML=tabledata;

}

display(employees);
function searchByName(){
    let searchValue=document.getElementById("searchName").value;
    let newemployee=employees.filter(function(employee){
        return (employee.name.toUpperCase().indexOf(searchValue.toUpperCase())!=-1);
    });
display(newemployee);


}
function searchByCity(){
    let searchValue=document.getElementById("searchCity").value;
    let newemployee=employees.filter(function(employee){
        return (employee.city.toUpperCase().indexOf(searchValue.toUpperCase())!=-1);
    });
display(newemployee);

}

function deleteemployee(index){
    employees.splice(index,1);
    display(employees);
  
}
